Thanks for purchasing Producto!

If you'd like to use the handwritten font from v1.0 for your subheaders,
replace all instances of .subheader with .hand.

Any issues or queries? Email me: josh@recursive.com.au.